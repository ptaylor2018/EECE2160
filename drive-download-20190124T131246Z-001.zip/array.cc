#include <iostream>
#include <stdlib.h>
void PrintArray(int v[], int size)
{
	for(int i = 0; i < size; i++)
	{
		std::cout<<v[i] << " ";
	}
	std::cout<<'\n';
}

void RandomArray(int v[], int size){
	for(int i = 0; i<size; i++){
		int Vrand;
		Vrand = rand()%100;
		v[i] = Vrand;
	}
}

void SortArray(int v[], int size){
	for(int i = 0; i<size; i++){
		int min = v[i];
		int minPlace;
		//find min
		for(int j = i+1; j < size; j ++){
			if(v[j] <= min){
                    		min = v[j];
				minPlace = j;
             		 }	
		}
		//swap
		int temp;
		temp = v[i];
		v[i] = min;
		v[minPlace] = temp;
	}

}


int main()
{
	int v[10];
	RandomArray(v, 10);
	PrintArray(v, 10);
	SortArray(v, 10);
	PrintArray(v, 10);
	return 0;
}

